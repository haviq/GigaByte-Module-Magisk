Versi: 10.0 Stabil (v1) - Inisialisasi skrip di tingkat sistem

Versi: 11.0 Stabil (v2) 
- Tingkatkan Ukuran Tumpukan 
- Aktivasi paksa LTE-A, AGPS 
- Tentukan frekuensi untuk LTE dan atur jenis jaringan default 
- Peningkatan kualitas penerimaan 2G dan 3G 
- Penggantian TCP/IP = 64MB/3000/3000 
- Nonaktifkan patch EAP-SIM

Versi: 12.0 Stabil (v3) 
- Ganti HeapSize untuk RAM 
- Aktifkan pemeriksaan RAM 
- Aktifkan TCP Buka Cepat 
- Peningkatan jumlah maksimum deskriptor file terbuka 
- Aktivasi dan penggantian pengaturan default untuk RMEM dan WMEM

Versi: 13.0 Stabil (v4) 
- Peningkatan situasi dengan RSRP, RSRQ, SINR dan RSSI 
- Optimasi dan koreksi band untuk operator seluler 
- DTM (Mode Transfer Ganda) diaktifkan 
- Daftar jaringan yang diperluas (EONS) diaktifkan 
- Broadband diaktifkan (AMR) 
- Meningkatkan ukuran memori yang dialokasikan untuk menyimpan koneksi jaringan
- Mengoptimalkan tumpukan jaringan dengan mengkonfigurasi ulang algoritma kontrol kemacetan TCP dan jenis kontrol yang berbeda dari laju transmisi awal setelah waktu idle 
- Peningkatan penerimaan TCP dan manajemen ukuran buffer transmisi 
- Menambahkan buffering sisi kernel

Versi: 14.0 Stabil (v5) 
- Mengubah metode memasukkan parameter build.prop 
- Memperbaiki HeapSize 
- pengaturan sekarang lebih fleksibel 
- Menambahkan fungsi untuk mengurangi latensi jaringan 
- Parameter registrasi GPRS baru telah diinstal 
- Parameter buffer jaringan baru
- Mengubah grid parameter untuk IPtables 
- sekarang semuanya dalam satu fungsi untuk memudahkan proses dan mempercepatnya 
- Menambahkan penangan kesalahan untuk level 01x(xx) 
- Menambahkan perbaikan kesalahan untuk pemilik perangkat Pixel dengan prosesor Tensor, sekarang seharusnya tidak masuk ke Bootloop. Diperlukan tes :)

Versi: 101.0 DevFixTest (v6) 
- Kode dioptimalkan 
- Memperbaiki beberapa bug yang menyebabkan Magisk, App Manager, dan YouTube mogok tanpa henti.

Versi: 101.1 DevFixTest (v6.1) 
- Algoritma deteksi Tensor yang diubah 
- Perbaikan kecil

Versi: 17.0 Stabil (v7) 
- Algoritma deteksi tensor telah diubah sepenuhnya 
- Perbaikan kecil 
- Peningkatan metode untuk membuat perubahan pada IPTables 
- Menambahkan layar "sangat mudah". 
- Pembersihan cache Wi-Fi diaktifkan

Versi: 102.1 DevFixTest (8.0) 
- Mengubah jaringan MTU (Unit Transmisi Maksimum) menjadi deteksi tingkat lanjut 
- Mengubah kontrol batas waktu (dalam detik) untuk menutup koneksi dalam status FIN-WAIT-2 
- Lubang keamanan dalam menggunakan fungsi Periksa CONNMARK ditutup 
- Rantai MARK dihilangkan dan ditulis ulang untuk menggunakan fungsi tersebut

Versi: 102.2 DevFixTest (8.1) 
- Pengerjaan ulang LTE-A, aktivasi A-GPS 
- Mode LTE ketat diaktifkan 
- Perintah LTE Advanced untuk modem diaktifkan

Versi: 102.3 DevFixTest (8.2) 
- Mengaktifkan MSAA untuk digunakan secara default seperti yang diminta oleh beberapa orang 
- Mengaktifkan AKF (Perbaikan Kernel Otomatis) untuk me-reboot perangkat secara otomatis jika terjadi kesalahan kernel kritis 
- Menambahkan fungsi untuk mengubah TTL ke nilai acak

Versi: 18.0 Stabil (v8.1) 
- Mengubah jaringan MTU (Unit Transmisi Maksimum) menjadi deteksi tingkat lanjut 
- Mengubah kontrol batas waktu (dalam detik) untuk menutup koneksi dalam status FIN-WAIT-2 
- Memperbaiki lubang keamanan dalam menggunakan fungsi Periksa CONNMARK 
- Rantai MARK telah ditulis ulang untuk menggunakan fungsi tersebut
- Pengerjaan ulang LTE-A, aktivasi A-GPS 
- Membangun kembali mode LTE yang ketat 
- Perintah LTE Advanced untuk modem diaktifkan 
- Mengaktifkan MSAA untuk digunakan secara default seperti yang diminta oleh beberapa orang 
- Mengaktifkan AKF (Perbaikan Kernel Otomatis) untuk me-reboot perangkat secara otomatis jika terjadi kesalahan kernel kritis 
- Menambahkan fungsi untuk mengubah TTL ke nilai acak

Versi: 19.0 Stabil (v9) 
- LAA (Akses Bantuan Berlisensi): Memungkinkan penggunaan spektrum tidak berlisensi untuk meningkatkan kinerjanya. 
- CA (Agregasi Operator): Agregasi multi-operator diaktifkan. 
- MIMO (Multiple-Input Multiple-Output): Memungkinkan penggunaan empat antena untuk mengirim dan menerima data, yang memungkinkan peningkatan kinerja dan peningkatan kualitas komunikasi di jaringan LTE 
- RxDiv (Receiver Diversity): Mengaktifkan kontrol pembagian sinyal penerima untuk meningkatkan penerimaan sinyal di lingkungan seluler. 
- MACAR (MAC Address Random): Ubah alamat MAC perangkat menjadi acak setiap 10 menit 
- TTLRV (Nilai Acak TTL): Ubah TTL perangkat menjadi acak setiap 10 menit 
- LTEAA (Agregasi Ditambahkan): Menambahkan fungsi untuk menentukan nilai maksimum agregasi dan menambahkannya 
- Menghapus sirkuit yang tidak berfungsi pada sebagian besar perangkat CONNMARK 
- Menghapus rantai MARK / 1x0B2 yang tidak digunakan
- Kode yang disederhanakan untuk fungsi pembersihan cache WiFi 
- Menambahkan pembersihan cache Bluetooth dan dikombinasikan dengan fungsi pembersihan cache WiFi (pada beberapa perangkat, karena alasan tertentu yang tidak saya ketahui, cache Bluetooth mengganggu pengoperasian normal pembersih WiFi

Versi: 20.0 Stabil (v10) 
- Karena konflik antarmuka jaringan dengan beberapa aplikasi termasuk Magisk, NetCam, YouTube, dll. Fungsi MACAR dihapus 
- Setelah mempelajari lebih cermat beberapa fitur jaringan Android, fungsi perubahan TTL dibangun kembali agar berfungsi dengan SDK tertentu mulai dari SDK 29 dan lebih tinggi
- Heapsize sekarang menyesuaikan tidak hanya dengan jumlah RAM. Kini fungsinya menjadi lebih pintar dan menentukan merek perangkat tanpa memperhitungkan kasus lalu menyesuaikan ukuran Heapsize tertentu untuk pabrikan tertentu dengan jumlah RAM


Versi: 20.1 Stabil (Perbaikan v10.1) 
- Algoritma untuk menghilangkan DDTR telah dihilangkan 
- Parameter boolean Heapsize yang diperbarui 
- Parameter logika TTL yang diperbarui 
- Parameter logis yang diperbarui di bawah BusyBox 
- File pendukung yang diperbarui 
- Merakit kembali komponen logis Heapsize 
- Merakit kembali komponen logis TTL 
- Mengembalikan fungsi MACAR dengan struktur logika pengacakan yang diperbarui

Versi: 21.0 Final Stabil (v11) 
- Mengedit alamat dan rute 
- Memperbaiki bug yang diketahui: kehilangan WiFi, trik OnePlus dan Oppo/Vivo/Samsung dengan Magisk/Kernel SU/Kitsune Magisk/APatch - BusyBox dan fungsinya dihilangkan demi keserbagunaan

Fitur tambahan : 
- sudah di tanamkan ADB TCP IP 192.168.8.1
- VNSTAT
- AUTO TTL 64
- AUTO IP 192.168.1.1