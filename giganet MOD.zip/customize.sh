MODNAME="gigainternet"
DEVNAME="David,Mas Pendi"
MODREQ="BusyBox and Magisk 23+"
MODAND="10"
DEVLINK="@dvdstore.sukabumi.jabar"
LINKHUB="https://t.me/david_25zx"

echo ""

rm -rf /data/local/tmp/gigalog.txt
# printf "\n" >> $LOG_FILE
LOG_FILE="/data/local/tmp/gigalog.txt"

# Ubah versi menjadi nilai numerik untuk perbandingan
current_version=$(getprop ro.build.version.release)
MODAND_NUM=$(echo "$MODAND" | awk -F'.' '{ printf("%d%02d", $1, $2); }')
current_version_NUM=$(echo "$current_version" | awk -F'.' '{ printf("%d%02d", $1, $2); }')

sleep 2
echo " • Saya memulai pemeriksaan" | tee -a $LOG_FILE
# Memeriksa Versi Android
echo " • Memeriksa Versi Android" | tee -a $LOG_FILE
if [ "$current_version_NUM" -lt "$MODAND_NUM" ]; then
  echo " • Kesalahan: Versi Android tidak cocok" | tee -a $LOG_FILE
  exit 1
fi

sleep 2
# Menentukan jumlah RAM dalam gigabyte
total_ram_kb=$(cat /proc/meminfo | grep "MemTotal" | tr -s ' ' | cut -d ' ' -f 2)
total_ram_gb=$(echo "scale=2; ${total_ram_kb} / (1024 * 1024)" | bc)
echo " • Menentukan jumlah RAM: ${total_ram_gb} Gb" | tee -a $LOG_FILE
  
#sleep 2
# Memeriksa keberadaan utilitas BusyBox
#echo " • Memeriksa Ketersediaan BusyBox" | tee -a $LOG_FILE
#if [ "$(id -u)" -eq "0" ]; then
#  if ! which busybox > /dev/null; then
#    echo " • Kesalahan: BusyBox tidak ditemukan" | tee -a $LOG_FILE
#    exit 1
#  fi
#fi

#sleep 2
# Memeriksa keberadaan modul kernel CONNMARK
#echo " • Cari modul CONNMARK"
#if lsmod | grep -q "CONNMARK"; then
#echo " • Modul CONNMARK ditemukan" | tee -a $LOG_FILE
#else
#echo " • Modul CONNMARK tidak ditemukan" | tee -a $LOG_FILE
#fi

sleep 2
# Berfungsi untuk mencari dan memeriksa argumen di string ro.soc.manufacturer
#echo " • Menguji di Google Tensor" | tee -a $LOG_FILE
#prop_file="/vendor/build.prop"
#if grep -q "ro.soc.manufacturer=Google" "$prop_file"; then
#  echo "Kesalahan: Pemasangan komponen inti tidak dapat dilakukan, Anda memiliki Prosesor Tensor" | tee -a $LOG_FILE
#  exit 1  # Larangan pemasangan modul
#fi
TENSORCHECK="Tensor\|Tensor G2\|Tensor G3\|Tensor G4\|GS201"
echo " • Menguji di Google Tensor"
if grep -Eq "ro.soc.model=($TENSORCHECK)" /vendor/build.prop && grep -Eq "ro.soc.model=($TENSORCHECK)" /system/build.prop; then
  echo " • Kesalahan: Tensor terdeteksi, menyetel ulang pemasangan modul"
  exit 1  # Larangan pemasangan modul
fi

sleep 2
echo " • Semua pemeriksaan telah berlalu, saya memulai instalasi" | tee -a $LOG_FILE

sleep 2
echo ""
echo " • Perangkat      : $(getprop ro.product.name) | $(getprop ro.product.system.model) | $(getprop ro.product.system.brand) "
echo " • versi SoC      : $(getprop ro.product.board) "
echo " • versi Android  : $(getprop ro.build.version.release) | SDK: $(getprop ro.build.version.sdk)"
echo " • versi ABI      : $(getprop ro.product.cpu.abi) "
echo " • CPU       : $(getprop ro.soc.model) "
echo " • ROM             : $(getprop ro.build.display.id) "
echo " • Inti            : $(uname -r) "
echo ""

sleep 2
echo " • Optimasi TCP/IP"
echo " • Optimasi Wi-Fi"
echo " • Optimasi RSRP, RSRQ, SINR & RSSI"
echo " • Optimasi tumpukan jaringan"
echo " • Kalibrasi lalu lintas data"
#echo " • Kalibrasi IPTable"
echo " • Mengubah Kontrol Ukuran Buffer Penerimaan dan Pengiriman TCP"
echo " • Mengubah nilai HeapSize agar sesuai dengan jumlah RAM"
echo " • Aktifkan TTLRV (Nilai Acak TTL)"
echo " • Aktifkan DTL, EONS dan AMR"
echo " • Aktifkan MSAA secara default"
echo " • Mengaktifkan AKF (Perbaikan Kernel Otomatis)"
echo " • Mengaktifkan LAA (Akses Bantuan Berlisensi)"
echo " • Aktifkan MIMO (Multi-Input Multiple-Output)"
echo " • Mengaktifkan RxDiv (Keberagaman Penerima)"
echo " • Aktivasi CA (Agregasi Operator)"
echo " • Aktifkan TCP Buka Cepat"
echo " • Mengaktifkan dan mengesampingkan pengaturan default untuk RMEM dan WMEM"
echo " • Mengaktifkan perintah LTE Advanced untuk modem"
#echo " • Mengaktifkan fungsi pembangkitan nilai TTL acak"
echo " • Menambahkan MACAR (Alamat MAC Acak)"
echo " • Menambahkan LTEAA (Agregasi Ditambahkan)"
echo " • Meningkatkan jumlah maksimum deskriptor file yang terbuka"
echo " • Aktivasi paksa LTE-A, AGPS"
echo " • Menonaktifkan patch EAP-SIM"
echo " • Script berhasil menyelesaikan tugasnya"
echo " • Menyelesaikan instalasi"

sleep 5
echo ""
echo ""
echo ""
echo " | Blok informasi"
echo " |"
echo " | Modul ini mencoba untuk meningkatkan"
echo " | koneksi jaringan dan meningkat"
echo " | Kecepatan internet di ponsel Anda"
echo " |"
echo " | Untuk menghindari masalah saat"
echo " | memuat sistem operasi, "
echo " | pasang modul Bootloop Protector"
echo ""
echo " | • Pengembang:      $DEVNAME"
echo " | • Persyaratan:        $MODREQ"
echo " | • Telegram:          $DEVLINK"
echo " | • Tg group:          $LINKHUB"
echo ""
echo " | Terima kasih khusus kepada orang ini atas bantuan mereka:"
echo " | Pengembang: @David, @Mas Pendi"
echo " | Penguji: @David, @Mas Pendi, @iyam, @enda, @Arga, @Winni"
echo " | SUKABUMI JABAR TETAP JAYA SELALU X WANI PEURIH"
echo " | (DVDSTORE GRUP)"
echo ""